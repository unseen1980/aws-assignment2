"use strict";

const AWS = require("aws-sdk");
const S3 = new AWS.S3({
  signatureVersion: "v4",
});
const Jimp = require("jimp");

const BUCKET = "s3-u-767fc203-2701-48fa-ae48";

exports.handler = async (event) => {
  // console.log("--1-->", event);
  // console.log("--2A-->", event.Records[0]);
  let eventCopy = {};
  event.Records.forEach((record) => {
    const { body } = record;
    eventCopy = Object.assign({}, JSON.parse(body));
    console.log("--2WCCZZT-->", eventCopy);
    console.log(
      "--2WCCCZZZZTFFF-->",
      eventCopy["Records"][0]["s3"]["object"]["key"]
    );
    console.log("--2WCCCZZZZTFFF****-->", eventCopy.Records[0].s3.object.key);
    // const x = JSON.stringify(body);
    // console.log("--2Fa-->", x);
    // const b = JSON.parse(x);
    // console.log("--2Fb-->", b["Records"]);
    // b.Records.forEach((record) => {
    //   console.log("--2Fc-->", record);
    // });
  });
  // console.log("--2A-->", JSON.parse(event.Records[0].body.s3));
  // console.log("--3-->", event.Records[0].s3);
  // console.log("--4-->", event.Records[0].s3.object);
  // console.log("--5-->", event.Records[0].s3.object.key);
  if (
    eventCopy.Records[0].s3.object &&
    eventCopy.Records[0].s3.object.key.indexOf(".png") > 0
  ) {
    const width = 640;
    const height = 480;
    const originalKey = eventCopy.Records[0].s3.object.key;

    const _image = await Jimp.read(
      `https://${BUCKET}.s3.eu-west-1.amazonaws.com/${originalKey}`
    );
    const _operatedImage = _image.resize(width, height);
    console.log("+++++++", _operatedImage);
    // const _operatedImageBuffer = await

    // _operatedImage.getBuffer(Jimp.MIME_PNG).then((buffer) => {
    //   console.log("*******", buffer);
    // const jimpBuffer = await _image.getBufferAsync(Jimp.MIME_PNG);
    _operatedImage.getBufferAsync(Jimp.MIME_PNG).then(async (jimpBuffer) => {
      console.log("Brooo", jimpBuffer);
      // S3.upload(
      //   {
      //     Body: jimpBuffer,
      //     Bucket: BUCKET,
      //     ContentType: "image",
      //     Key: `small_${originalKey}`,
      //   },
      //   function (s3Err, data) {
      //     if (s3Err) throw s3Err;
      //     console.log(`File uploaded successfully at ${data.Location}`);
      //   }
      // );

      const params = {
        Bucket: BUCKET,
        Key: `is_this_real_life.txt`,
        Body: JSON.stringify(jimpBuffer),
      };

      try {
        const response = await S3.upload(params).promise();
        console.log("Response: ", response);
        return response;
      } catch (err) {
        console.log(err);
      }
    });

    // });
    // console.log("*******", _operatedImageBuffer);
    // S3.putObject({
    //   Body: _operatedImageBuffer,
    //   Bucket: BUCKET,
    //   ContentType: "image/png",
    //   Key: `'small_'${originalKey}`,
    // }).promise();

    // try {
    //   const putResult = await s3
    //     .putObject({
    //       Body: _operatedImageBuffer,
    //       Bucket: BUCKET,
    //       ContentType: "image/png",
    //       Key: `'small_'${originalKey}`,
    //     })
    //     .promise();
    // } catch (error) {
    //   console.log(error);
    //   return;
    // }

    // S3.getObject({ Bucket: BUCKET, Key: originalKey })
    //   .promise()
    //   .then((data) =>
    //     // Sharp(data.Body).resize(width, height).toFormat("png").toBuffer()
    //     {
    // await Jimp.read(
    //   `https://${BUCKET}.s3.eu-west-1.amazonaws.com/${originalKey}`
    // )
    //   .then((image) => {
    //     console.log("Before resizing", image);
    //     return image
    //       .resize(width, height) // resize
    //       .quality(90); // set JPEG quality
    //   })
    //   .then((buffer) => {
    //     S3.putObject({
    //       Body: buffer,
    //       Bucket: BUCKET,
    //       ContentType: "image/png",
    //       Key: `'small_'${originalKey}`,
    //     }).promise();
    //   })
    //   .catch((err) => {
    //     throw err;
    //   })
    //   .finally(() => {
    //     console.info("Function ran successfully");
    //   });
    //   }
    // );
    // .then((buffer) =>
    //   S3.putObject({
    //     Body: buffer,
    //     Bucket: BUCKET,
    //     ContentType: "image/png",
    //     Key: `'small_'${originalKey}`,
    //   }).promise()
    // );
  }
};
